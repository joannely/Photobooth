function enterPhotobooth() {
	document.location.href = 'home.html';
}