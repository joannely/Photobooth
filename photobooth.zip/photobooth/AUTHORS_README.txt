Authors:
Darren Chan 912375331 darchan@ucdavis.edu port #:7686
Joanne Wang 913360523 jnewang@ucdavis.edu port #:10305

splash screen: http://138.68.25.50:10305/photo/photobooth.html
main page: http://138.68.25.50:10305/photo/home.html
currently, both filtering by keyword and filtering by favorites work. filtering by a label keyword while looking at favorites also works, and vice versa. progress bar is inanimate.